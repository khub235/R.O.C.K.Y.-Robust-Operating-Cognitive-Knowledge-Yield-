@echo off
set PYTHONIOENCODING=utf-8
cd /d "%~dp0"
python -u main.py > rocky_output.log 2>&1
